// SETBoard Web白板 - 核心引擎
(function(){
'use strict';

// ============ 工具函数 ============
function hexToRGBA(hex){
  var r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);
  return{r,g,b};
}
function rgbaToHexStr(r,g,b,a){return((a<<24)|(r<<16)|(g<<8)|b).toString(16).slice(0,8);}
function hexToRGBAstr(hex){var c=hexToRGBA(hex);return 'FF'+c.r.toString(16).padStart(2,'0')+c.g.toString(16).padStart(2,'0')+c.b.toString(16).padStart(2,'0');}

// ============ 文档/页面管理 ============
var doc={
  pages:[],
  currentPageIndex:0,
  background:0xFFFFFFFF,
  showGrid:true,
  gridSize:34
};

function getCurrentPage(){return doc.pages[doc.currentPageIndex];}
function saveState(){
  var pg=getCurrentPage();
  return{items:JSON.parse(JSON.stringify(pg.items||[]))};
}

// ============ InkStroke (墨迹) ============
var InkStroke=function(color,width,highlighter){
  this.points=[];
  this.color=color||0xFF1A1A1A;
  this.width=width||4;
  this.highlighter=!!highlighter;
  this._bounds=null;
};

InkStroke.prototype.addPoint=function(x,y,pressure,minDist){
  var p=Math.max(0.05,Math.min(1,pressure));
  if(this.points.length>0){
    var last=this.points[this.points.length-1];
    if(Math.abs(last.x-x)<minDist&&Math.abs(last.y-y)<minDist){
      this.points[this.points.length-1]={x:x,y:y,p:p};
      this._recalcBounds();return;
    }
  }
  this.points.push({x:x,y:y,p:p});
  var hw=this.width*(this.highlighter?1.5:0.7);
  var b={x:x-hw,y:y-hw,x2:x+hw,y2:y+hw};
  if(this.points.length===1)this._bounds=b;
  else this._unionBounds(b);
};

InkStroke.prototype._recalcBounds=function(){
  if(!this.points.length)return;
  var hw=this.width*(this.highlighter?1.5:0.7),mnX=1e9,mnY=1e9,mxX=-1e9,mxY=-1e9;
  for(var i=0;i<this.points.length;i++){
    var pt=this.points[i];
    if(pt.x<mnX)mnX=pt.x;if(pt.y<mnY)mnY=pt.y;
    if(pt.x>mxX)mxX=pt.x;if(pt.y>mxY)mxY=pt.y;
  }
  this._bounds={x:mnX-hw,y:mnY-hw,x2:mxX+hw,y2:mxY+hw};
};

InkStroke.prototype._unionBounds=function(b){
  var o=this._bounds||{x:1e9,y:1e9,x2:-1e9,y2:-1e9};
  this._bounds={x:Math.min(o.x,b.x),y:Math.min(o.y,b.y),x2:Math.max(o.x2,b.x2),y2:Math.max(o.y2,b.y2)};
};

InkStroke.prototype.getBounds=function(){return this._bounds||{x:0,y:0,x2:0,y2:0};};

// Catmull-Rom 插值采样
InkStroke.prototype.getRenderPoints=function(){
  var pts=this.points;if(!pts.length)return[];
  if(pts.length<2)return pts;
  // 去重+平滑
  var filtered=[pts[0]];
  var minStep=Math.max(0.5,this.width*0.1);
  for(var i=1;i<pts.length;i++){
    var last=filtered[filtered.length-1];
    if(Math.sqrt((last.x-pts[i].x)*(last.x-pts[i].x)+(last.y-pts[i].y)*(last.y-pts[i].y))<minStep){
      filtered[filtered.length-1]={x:pts[i].x,y:pts[i].y,p:(last.p+pts[i].p)*0.5};
    }else{filtered.push(pts[i]);}
  }
  var n=filtered.length;
  if(n<3)return filtered;
  // 轻度平滑
  var smoothed=[filtered[0]];
  for(var i=1;i<n-1;i++){
    var a=filtered[i-1],b=filtered[i],c=filtered[i+1];
    // 只在轻微弯曲时平滑
    var dx1=b.x-a.x,dy1=b.y-a.y,dx2=c.x-b.x,dy2=c.y-b.y;
    var ang=Math.atan2(dy1,dx1)-Math.atan2(dy2,dx2);
    if(ang>Math.PI)ang-=2*Math.PI;if(ang<-Math.PI)ang+=2*Math.PI;
    if(Math.abs(ang)>35*Math.PI/180){smoothed.push(b);}
    else{smoothed.push({x:(a.x+b.x*2+c.x)*0.25,y:(a.y+b.y*2+c.y)*0.25,p:(a.p+b.p*2+c.p)*0.25});}
  }
  smoothed.push(filtered[n-1]);
  return smoothed;
};

InkStroke.prototype.draw=function(ctx,ox,oz){
  var pts=this.getRenderPoints();if(!pts.length)return;
  var halfW=this.width*0.5;
  var colorStr='#'+this.color.toString(16).slice(2);
  var alpha=(this.color>>24)&0xFF;
  ctx.globalAlpha=alpha/255;

  if(this.highlighter){
    ctx.strokeStyle=colorStr;
    ctx.lineWidth=this.width*3;
    ctx.lineCap='round';ctx.lineJoin='round';
    ctx.beginPath();
    var rpts=this.getRenderPoints();
    if(rpts.length===0)return;
    ctx.moveTo(rpts[0].x*oz+ox,rpts[0].y*oz+oy);
    for(var i=1;i<rpts.length;i++){ctx.lineTo(rpts[i].x*oz+ox,rpts[i].y*oz+oy);}
    ctx.stroke();
  }else if(pts.length===1){
    var r=halfW;
    ctx.fillStyle=colorStr;
    ctx.beginPath();
    ctx.arc(pts[0].x*oz+ox,pts[0].y*oz+oy,r*oz,r*2*Math.PI);
    ctx.fill();
  }else{
    // 构建笔迹几何：圆头+连接片
    var rpts=this.getRenderPoints();
    var n=rpts.length;
    if(n<2)return;

    // 计算半宽（压感+速度）
    var widths=[];
    for(var i=0;i<n;i++){
      var pr=Math.max(0.05,rpts[i].p);
      var pf=0.6+0.4*pr;
      var sp=0;
      if(i>0&&i<n-1){
        sp=(Math.sqrt((rpts[i-1].x-rpts[i].x)**2+(rpts[i-1].y-rpts[i].y)**2)+
            Math.sqrt((rpts[i+1].x-rpts[i].x)**2+(rpts[i+1].y-rpts[i].y)**2))*0.5;
      }else if(i>0){sp=Math.sqrt((rpts[i-1].x-rpts[i].x)**2+(rpts[i-1].y-rpts[i].y)**2);}
      else{sp=Math.sqrt((rpts[i+1].x-rpts[i].x)**2+(rpts[i+1].y-rpts[i].y)**2);}
      var speed=Math.min(1,Math.max(0,sp/(halfW*2*5)));
      var sf=1.25-0.4*speed;
      widths[i]=Math.max(0.3,halfW*pf*sf);
    }
    // 半径限速+平滑
    for(var i=1;i<widths.length;i++){
      var d=Math.sqrt((rpts[i-1].x-rpts[i].x)**2+(rpts[i-1].y-rpts[i].y)**2);
      widths[i]=widths[i-1]+Math.max(-d*0.3,Math.min(widths[i]-widths[i-1],d*0.3));
    }
    for(var i=widths.length-2;i>=0;i--){
      var d=Math.sqrt((rpts[i].x-rpts[i+1].x)**2+(rpts[i].y-rpts[i+1].y)**2);
      widths[i]=widths[i+1]+Math.max(-(d*0.3),Math.min(widths[i]-widths[i+1],d*0.3));
    }
    // 端头收锋
    var totalLen=0;
    for(var i=1;i<n;i++)totalLen+=Math.sqrt((rpts[i-1].x-rpts[i].x)**2+(rpts[i-1].y-rpts[i].y)**2);
    var refW=0;for(var j=0;j<widths.length;j++)if(widths[j]>refW)refW=widths[j];
    if(refW>0.3){
      var taper=Math.min(totalLen*0.3,refW*6);
      var tipRatio=1-0.7*Math.min(1,taper/(4*refW));
      var done=0;
      for(var k=0;k<n&&done<taper;k++){
        var idx=k;
        if(k>0){var dx=rpts[idx].x-rpts[idx-1].x,dy=rpts[idx].y-rpts[idx-1].y;done+=Math.sqrt(dx*dx+dy*dy);}
        widths[idx]*=tipRatio+(1-tipRatio)*Math.min(1,done/taper);
      }
      done=0;
      for(var k=0;k<n&&done<taper*1.3;k++){
        var idx=n-1-k;
        if(k>0){var dx2=rpts[idx+1].x-rpts[idx].x,dy2=rpts[idx+1].y-rpts[idx].y;done+=Math.sqrt(dx2*dx2+dy2*dy2);}
        widths[idx]*=tipRatio+(1-tipRatio)*Math.min(1,done/(taper*1.3));
      }
    }

    // 用 Catmull-Rom 插值加密采样点
    var finalPts=[],finalW=[];
    finalPts.push(rpts[0]);finalW.push(widths[0]);
    for(var i=0;i<n-1;i++){
      var p0=rpts[i],p1=rpts[i+1],w0=widths[i],w1=widths[i+1];
      var dx=p1.x-p0.x,dy=p1.y-p0.y,chord=Math.sqrt(dx*dx+dy*dy);
      if(chord<0.0001){finalPts.push(p1);finalW.push(w1);continue;}
      var step=Math.max(Math.min(w0,w1)*0.55,Math.max(chord/4000,0.6));
      var steps=Math.max(1,Math.ceil(chord/step));
      for(var s=1;s<=steps;s++){
        var u=s/steps;
        finalPts.push({x:p0.x+dx*u,y:p0.y+dy*u});
        finalW.push(w0+(w1-w0)*u);
      }
    }

    // 绘制：圆头 + 连接片
    ctx.fillStyle=colorStr;
    var fp=finalPts,fw=finalW;
    for(var i=0;i<fp.length;i++){
      var r=fw[i]*oz;
      if(r>0.3){
        var steps=r<=3?6:r<=8?8:10;
        ctx.beginPath();
        for(var s=0;s<=steps;s++){
          var ang=2*Math.PI*s/steps;
          var px=fp[i].x*oz+ox+r*Math.cos(ang);
          var py=fp[i].y*oz+oy+r*Math.sin(ang);
          if(s===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);
        }
        ctx.fill();
      }
    }
    // 连接片
    for(var i=0;i<fp.length-1;i++){
      var a=fp[i],b=fp[i+1],wA=fw[i]*oz,wB=fw[i+1]*oz;
      var ddx=b.x-a.x,ddy=b.y-a.y,len=Math.sqrt(ddx*ddx+ddy*ddy);
      if(len<0.0001)continue;
      if(len<=Math.min(wA,wB)*0.6)continue;
      var nx=-ddy/len,ny=ddx/len;
      ctx.beginPath();
      ctx.moveTo(a.x*oz+ox+wA*nx,a.y*oz+oy+wA*ny);
      ctx.lineTo(b.x*oz+ox+wB*nx,b.y*oz+oy+wB*ny);
      ctx.lineTo(b.x*oz+ox-wB*nx,b.y*oz+oy-wB*ny);
      ctx.lineTo(a.x*oz+ox-wA*nx,a.y*oz+oy-wA*ny);
      ctx.closePath();ctx.fill();
    }
  }
  ctx.globalAlpha=1;
};

InkStroke.prototype.hitTest=function(x,y,tol){
  var halfW=this.width*(this.highlighter?1.5:0.75)+tol;
  if(this.points.length===1){
    var dx=this.points[0].x-x,dy=this.points[0].y-y;
    return Math.sqrt(dx*dx+dy*dy)<=halfW;
  }
  for(var i=1;i<this.points.length;i++){
    if(distToSeg(x,y,this.points[i-1].x,this.points[i-1].y,this.points[i].x,this.points[i].y)<=halfW)return true;
  }
  return false;
};

InkStroke.prototype.eraseAt=function(cx,cy,radius){
  var limit=radius+this.width*(this.highlighter?1.5:0.5);
  var segs=[],cur=[];
  for(var i=0;i<this.points.length;i++){
    var pt=this.points[i];
    if(Math.sqrt((pt.x-cx)**2+(pt.y-cy)**2)<=limit){
      if(cur.length>=2)segs.push(cur.slice());
      cur=[];
    }else{cur.push(pt);}
  }
  if(cur.length>=2)segs.push(cur);
  var result=[];
  for(var i=0;i<segs.length;i++){
    var ns=new InkStroke(this.color,this.width,this.highlighter);
    ns.points=segs[i];ns._bounds=null;ns._recalcBounds();result.push(ns);
  }
  return result;
};

InkStroke.prototype.translate=function(dx,dy){
  for(var i=0;i<this.points.length;i++){this.points[i].x+=dx;this.points[i].y+=dy;}
  this._recalcBounds();
};

// ============ ShapeItem ============
var ShapeItem=function(kind,color,width){
  this.kind=kind||'line';this.color=color||0xFF1A1A1A;this.width=width||4;
  this.x1=0;this.y1=0;this.x2=0;this.y2=0;
};
ShapeItem.prototype.getBounds=function(){
  var l=Math.min(this.x1,this.x2),t=Math.min(this.y1,this.y2);
  return{x:l,y:t,x2:l+Math.abs(this.x2-this.x1),y2:t+Math.abs(this.y2-this.y1)};
};
ShapeItem.prototype.draw=function(ctx,ox,oz){
  var colorStr='#'+this.color.toString(16).slice(2);
  ctx.strokeStyle=colorStr;ctx.lineWidth=this.width*oz;ctx.lineCap='round';ctx.lineJoin='round';
  var x1=this.x1*oz+ox,y1=this.y1*oz+oy,x2=this.x2*oz+ox,y2=this.y2*oz+oy;
  switch(this.kind){
    case'line':ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();break;
    case'arrow':
      ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();
      var dx=x2-x1,dy=y2-y1,len=Math.sqrt(dx*dx+dy*dy);
      if(len>0.01){
        var nx=-dy/len,ny=dx/len,head=Math.max(12,this.width*3.6*oz);
        var bcx=x2-dx/len*head,bcy=y2-dy/len*head;
        ctx.beginPath();ctx.moveTo(x2,y2);
        ctx.lineTo(bcx+nx*head*0.42,bcy+ny*head*0.42);
        ctx.lineTo(bcx-nx*head*0.42,bcy-ny*head*0.42);
        ctx.closePath();ctx.fill();
      }
      break;
    case'rectangle':ctx.strokeRect(x1,y1,x2-x1,y2-y1);break;
    case'ellipse':
      var cx=(x1+x2)/2,cy=(y1+y2)/2,rx=Math.abs(x2-x1)/2,ry=Math.abs(y2-y1)/2;
      ctx.beginPath();ctx.ellipse(cx,cy,rx,ry,0,0,2*Math.PI);ctx.stroke();break;
    case'triangle':
      var tx=(x1+x2)/2;
      ctx.beginPath();ctx.moveTo(tx,y1);ctx.lineTo(x2,y2);ctx.lineTo(x1,y2);ctx.closePath();ctx.stroke();break;
  }
};
ShapeItem.prototype.hitTest=function(x,y,tol){
  if(this.kind==='line'||this.kind==='arrow')return distToSeg(x*1/oz-ox/oz,y*1/oz-oy/oz,this.x1,this.y1,this.x2,this.y2)<=tol+this.width*0.5+2;
  var b=this.getBounds();
  return x>=b.x-tol&&x<=b.x2+tol&&y>=b.y-tol&&y<=b.y2+tol;
};
ShapeItem.prototype.translate=function(dx,dy){this.x1+=dx;this.y1+=dy;this.x2+=dx;this.y2+=dy;}

// ============ SolidItem (3D几何体) ============
var SolidItem=function(kind,color,size,height){
  this.kind=kind||'cube';this.color=color||0xFFFFFFFF;this.width=2.2;
  this.cx=0;this.cy=0;this.size=size||160;this.height=height||160;
  this.yaw=28;this.pitch=16;this.faceColors={};
};

SolidItem.prototype.getBounds=function(){
  var reach=Math.max(this.size,this.height)*0.72+this.width;
  return{x:this.cx-reach,y:this.cy-reach,x2:this.cx+reach,y2:this.cy+reach};
};

SolidItem.prototype.rotate=function(vx,vy,vz){
  var ya=this.yaw*Math.PI/180,pi=this.pitch*Math.PI/180;
  var cy=Math.cos(ya),sy=Math.sin(ya),cp=Math.cos(pi),sp=Math.sin(pi);
  var x=vx*cy+vz*sy,z=-vx*sy+vz*cy,y=vy*cp-z*sp;return{x:x,y:y,z:vy*sp+z*cp};
};

SolidItem.prototype.project=function(vx,vy,vz){
  var r=this.rotate(vx,vy,vz);
  return{x:this.cx+r.x,y:this.cy-r.y};
};

SolidItem.prototype.draw=function(ctx,ox,oz){
  var s=this.size/2,hh=this.height/2;
  switch(this.kind){
    case'cube':this._drawCube(ctx,ox,oz,s,hh);break;
    case'cuboid':this._drawCuboid(ctx,ox,oz,s,hh);break;
    case'pyramid':this._drawPyramid(ctx,ox,oz,s,hh);break;
    case'cylinder':this._drawCylinder(ctx,ox,oz,s,hh);break;
    case'cone':this._drawCone(ctx,ox,oz,s,hh);break;
    case'sphere':this._drawSphere(ctx,ox,oz,s);break;
  }
};

SolidItem.prototype._drawCube=function(ctx,ox,oz,s,hh){
  var vs=[
    this.project(-s,-hh,-s),this.project(s,-hh,-s),this.project(s,-hh,s),this.project(-s,-hh,s),
    this.project(-s,hh,-s),this.project(s,hh,-s),this.project(s,hh,s),this.project(-s,hh,s)
  ];
  var faces=[
    [0,1,2,3],[4,7,6,5],[0,4,5,1],[1,5,6,2],[2,6,7,3],[3,7,4,0]
  ];
  this._drawPolyhedron(ctx,vs,faces,ox,oz);
};

SolidItem.prototype._drawCuboid=function(ctx,ox,oz,s,hh){
  var d=s*0.72;
  var vs=[
    this.project(-s,-hh,-d),this.project(s,-hh,-d),this.project(s,-hh,d),this.project(-s,-hh,d),
    this.project(-s,hh,-d),this.project(s,hh,-d),this.project(s,hh,d),this.project(-s,hh,d)
  ];
  var faces=[
    [0,1,2,3],[4,7,6,5],[0,4,5,1],[1,5,6,2],[2,6,7,3],[3,7,4,0]
  ];
  this._drawPolyhedron(ctx,vs,faces,ox,oz);
};

SolidItem.prototype._drawPyramid=function(ctx,ox,oz,s,hh){
  var hs=s/2;
  var vs=[
    this.project(-hs,-hh,-hs),this.project(hs,-hh,-hs),this.project(hs,-hh,hs),this.project(-hs,-hh,hs),
    this.project(0,hh,0)
  ];
  var faces=[[0,1,2,3],[0,4,1],[1,4,2],[2,4,3],[3,4,0]];
  this._drawPolyhedron(ctx,vs,faces,ox,oz);
};

SolidItem.prototype._drawPolyhedron=function(ctx,vs,faces,ox,oz){
  // 简单画家算法绘制
  var colorStr='#'+this.color.toString(16).slice(2);
  ctx.strokeStyle=colorStr;ctx.lineWidth=this.width*oz;ctx.lineCap='round';

  // 计算面的深度和可见性
  var vis=[],depth=[];
  for(var i=0;i<faces.length;i++){
    var f=faces[i];
    var zSum=0;
    for(var j=0;j<f.length;j++)zSum+=vs[f[j]].y; // simplified Z
    depth[i]=zSum/f.length;
    vis[i]=(f[0].x+vs[f[1]].x+vs[f[2]].x)>this.cx*3; // simplified normal test
  }

  // 收集棱
  var edges={};
  for(var i=0;i<faces.length;i++){
    if(!vis[i])continue;
    for(var j=0;j<faces[i].length;j++){
      var a=faces[i][j],b=faces[i][(j+1)%faces[i].length];
      var key=Math.min(a,b)+'_'+Math.max(a,b);
      edges[key]={a:a,b:b};
    }
  }

  // 排序绘制
  var order=[];for(var i=0;i<faces.length;i++)order.push(i);
  order.sort(function(a,b){return depth[a]-depth[b];});

  for(var i=0;i<order.length;i++){
    if(!vis[order[i]])continue;
    var f=faces[order[i]];
    ctx.beginPath();ctx.moveTo(vs[f[0]].x*oz+ox,vs[f[0]].y*oz+oy);
    for(var j=1;j<f.length;j++)ctx.lineTo(vs[f[j]].x*oz+ox,vs[f[j]].y*oz+oy);
    ctx.closePath();
    if(this.faceColors[order[i]]){
      var fc='#'+this.faceColors[order[i]].toString(16).slice(2);
      ctx.fillStyle=fc+'19';ctx.fill();
    }
  }

  // 画棱
  for(var key in edges){
    var e=edges[key];
    if(vis[faces.find(function(f){return f.includes(e.a)&&f.includes(e.b)})||-1]){
      ctx.beginPath();ctx.moveTo(vs[e.a].x*oz+ox,vs[e.a].y*oz+oy);ctx.lineTo(vs[e.b].x*oz+ox,vs[e.b].y*oz+oy);ctx.stroke();
    }else{
      ctx.save();ctx.setLineDash([5*oz,4*oz]);
      ctx.beginPath();ctx.moveTo(vs[e.a].x*oz+ox,vs[e.a].y*oz+oy);ctx.lineTo(vs[e.b].x*oz+ox,vs[e.b].y*oz+oy);ctx.stroke();
      ctx.restore();
    }
  }
};

SolidItem.prototype._drawCylinder=function(ctx,ox,oz,s,hh){
  var r=s/2,hh2=this.height/2;
  const segs=48;
  var topPts=[],botPts=[];
  for(var i=0;i<segs;i++){
    var ang=2*Math.PI*i/segs;
    var tr=this.project(r*Math.cos(ang),-hh2,r*Math.sin(ang));
    var br=this.project(r*Math.cos(ang),hh2,r*Math.sin(ang));
    topPts.push(tr);botPts.push(br);
  }

  // 顶面椭圆
  ctx.beginPath();
  for(var i=0;i<segs;i++){var p=topPts[i];if(i===0)ctx.moveTo(p.x*oz+ox,p.y*oz+oy);else ctx.lineTo(p.x*oz+ox,p.y*oz+oy);}
  ctx.closePath();
  if(this.faceColors[0]){ctx.fillStyle='#'+this.color.toString(16).slice(2)+'19';ctx.fill();}
  var colorStr='#'+this.color.toString(16).slice(2);
  ctx.strokeStyle=colorStr;ctx.lineWidth=this.width*oz;ctx.stroke();

  // 侧面轮廓线
  var minX=0,maxX=0;
  for(var i=1;i<segs;i++){if(topPts[i].x<topPts[minX].x)minX=i;if(topPts[i].x>topPts[maxX].x)maxX=i;}
  ctx.beginPath();ctx.moveTo(topPts[minX].x*oz+ox,topPts[minX].y*oz+oy);ctx.lineTo(botPts[minX].x*oz+ox,botPts[minX].y*oz+oy);ctx.stroke();
  ctx.beginPath();ctx.moveTo(topPts[maxX].x*oz+ox,topPts[maxX].y*oz+oy);ctx.lineTo(botPts[maxX].x*oz+ox,botPts[maxX].y*oz+oy);ctx.stroke();

  // 底面椭圆（前半实线，后半虚线）
  ctx.save();ctx.setLineDash([5*oz,4*oz]);
  var front=false;
  for(var i=0;i<segs;i++){
    var next=(i+1)%segs;
    var midY=(botPts[i].y+botPts[next].y)/2;
    if(midY>this.cy)front=true;else front=false;
    if(i===0){ctx.beginPath();}
    ctx.lineTo(botPts[i].x*oz+ox,botPts[i].y*oz+oy);
  }
  ctx.stroke();ctx.restore();
};

SolidItem.prototype._drawCone=function(ctx,ox,oz,s,hh){
  var r=s/2,hh2=this.height/2;
  const segs=48;
  var botPts=[];
  for(var i=0;i<segs;i++){
    var ang=2*Math.PI*i/segs;
    botPts.push(this.project(r*Math.cos(ang),hh2,r*Math.sin(ang)));
  }
  var apex=this.project(0,-hh2,0);

  // 底面后半虚线
  ctx.save();ctx.setLineDash([5*oz,4*oz]);
  ctx.beginPath();
  for(var i=0;i<segs;i++)ctx.lineTo(botPts[i].x*oz+ox,botPts[i].y*oz+oy);
  ctx.closePath();ctx.stroke();ctx.restore();

  // 轮廓线
  var colorStr='#'+this.color.toString(16).slice(2);
  ctx.strokeStyle=colorStr;ctx.lineWidth=this.width*oz;ctx.lineCap='round';
  var minX=0,maxX=0;
  for(var i=1;i<segs;i++){if(botPts[i].x<botPts[minX].x)minX=i;if(botPts[i].x>botPts[maxX].x)maxX=i;}
  ctx.beginPath();ctx.moveTo(apex.x*oz+ox,apex.y*oz+oy);ctx.lineTo(botPts[minX].x*oz+ox,botPts[minX].y*oz+oy);ctx.stroke();
  ctx.beginPath();ctx.moveTo(apex.x*oz+ox,apex.y*oz+oy);ctx.lineTo(botPts[maxX].x*oz+ox,botPts[maxX].y*oz+oy);ctx.stroke();

  // 底面前半实线
  ctx.beginPath();
  for(var i=0;i<segs;i++)ctx.lineTo(botPts[i].x*oz+ox,botPts[i].y*oz+oy);
  ctx.closePath();ctx.stroke();
};

SolidItem.prototype._drawSphere=function(ctx,ox,oz,r){
  var colorStr='#'+this.color.toString(16).slice(2);
  ctx.strokeStyle=colorStr;ctx.lineWidth=this.width*oz;ctx.lineCap='round';
  ctx.beginPath();ctx.arc(this.cx*oz+ox,this.cy*oz+oy,r*oz,0,2*Math.PI);ctx.stroke();

  if(this.faceColors[0]){
    var fc='#'+this.color.toString(16).slice(2)+'19';
    ctx.fillStyle=fc;ctx.fill();
  }

  // 赤道
  this._drawGreatCircle(ctx,ox,oz,r,0);
  // 经线
  this._drawGreatCircle(ctx,ox,oz,r,Math.PI/2);
};

SolidItem.prototype._drawGreatCircle=function(ctx,ox,oz,r,rot){
  const segs=64;
  var solid=[],dashed=[];
  var prev=null,pv=null;
  for(var i=0;i<=segs;i++){
    var ang=2*Math.PI*i/segs;
    var x=r*Math.cos(ang),z=r*Math.sin(ang);
    var y=Math.sin(rot)*x+Math.cos(rot)*z;
    var p=this.project(x,y,z*0.1); // simplified
    var vis=p.y<this.cy; // simplified Z test

    if(prev&&pv===vis){
      solid.push(p);dashed.push(p);
    }else{
      if(vis)solid=[p];else dashed=[p];
    }
    prev=vis;pv=vis;
  }
  ctx.beginPath();for(var i=0;i<solid.length;i++){var p=solid[i];if(i===0)ctx.moveTo(p.x*oz+ox,p.y*oz+oy);else ctx.lineTo(p.x*oz+ox,p.y*oz+oy);}ctx.stroke();
  ctx.save();ctx.setLineDash([5*oz,4*oz]);
  ctx.beginPath();for(var i=0;i<dashed.length;i++){var p=dashed[i];if(i===0)ctx.moveTo(p.x*oz+ox,p.y*oz+oy);else ctx.lineTo(p.x*oz+ox,p.y*oz+oy);}ctx.stroke();ctx.restore();
};

SolidItem.prototype.hitTest=function(x,y,tol){
  var b=this.getBounds();return x>=b.x-tol&&x<=b.x2+tol&&y>=b.y-tol&&y<=b.y2+tol;
};
SolidItem.prototype.translate=function(dx,dy){this.cx+=dx;this.cy+=dy;}

// ============ FunctionItem (函数图像) ============
var FunctionItem=function(){
  this.expressions=[];this.xMin=-10;this.xMax=10;
  this.left=0;this.top=0;this.plotW=560;this.plotH=360;
  this.color=0xFFFFFFFF;this.width=3;this.yMin=-4;this.yMax=4;
};

FunctionItem.prototype.getBounds=function(){
  var p=this.width+4;return{x:this.left-p,y:this.top-p,x2:this.left+this.plotW+p,y2:this.top+this.plotH+p};
};

FunctionItem.prototype.mapX=function(x){return this.left+(x-this.xMin)/(this.xMax-this.xMin)*this.plotW;};
FunctionItem.prototype.mapY=function(y){return this.top+this.plotH-(y-this.yMin)/(this.yMax-this.yMin)*this.plotH;};

FunctionItem.prototype.parseExpr=function(expr,paramA){
  // 简单表达式解析器，支持 sin, cos, tan, sqrt, abs, pow, log, exp, x^2等
  var e=expr.replace(/\s/g,'').toLowerCase();
  e=e.replace(/\^/g,'**');
  e=e.replace(/sin\(/g,'Math.sin(').replace(/cos\(/g,'Math.cos(').replace(/tan\(/g,'Math.tan(');
  e=e.replace(/sqrt\(/g,'Math.sqrt(').replace(/abs\(/g,'Math.abs(');
  e=e.replace(/log\(/g,'Math.log(').replace(/exp\(/g,'Math.exp(');
  e=e.replace(/pi/g,'Math.PI').replace(/e(?![x])/g,'Math.E');
  if(e.includes('a')){
    var fn=new Function('x','a','var _a='+paramA+';try{return '+e+';}catch(e){return NaN;}');
    return function(x){return fn(x,_a);};
  }else{
    var fn2=new Function('x','try{return '+e+';}catch(e){return NaN;}');
    return function(x){return fn2(x);};
  }
};

FunctionItem.prototype.addCurve=function(expr,color,paramA){
  this.expressions.push({expr:expr,color:color||this.color,a:paramA||1});
};

FunctionItem.prototype.draw=function(ctx,ox,oz){
  var colorStr='#'+this.color.toString(16).slice(2);
  // 坐标轴
  ctx.strokeStyle=colorStr+'73';ctx.lineWidth=1.1*oz;
  if(this.yMin<0&&this.yMax>0){var y0=this.mapY(0);ctx.beginPath();ctx.moveTo(this.left*oz+ox,y0*oz+oy);ctx.lineTo((this.left+this.plotW)*oz+ox,y0*oz+oy);ctx.stroke();}
  if(this.xMin<0&&this.xMax>0){var x0=this.mapX(0);ctx.beginPath();ctx.moveTo(x0*oz+ox,this.top*oz+oy);ctx.lineTo(x0*oz+ox,(this.top+this.plotH)*oz+oy);ctx.stroke();}

  // 绘制每条曲线
  for(var ci=0;ci<this.expressions.length;ci++){
    var curve=this.expressions[ci];
    var fn=this.parseExpr(curve.expr,curve.a);
    var cs='#'+(curve.color||this.color).toString(16).slice(2);
    ctx.strokeStyle=cs;ctx.lineWidth=this.width*oz;ctx.lineCap='round';ctx.lineJoin='round';

    var samples=Math.min(Math.max(this.plotW*1.4,240),1800);
    var spanX=this.xMax-this.xMin;
    var prevY=null;
    ctx.beginPath();var started=false;
    for(var i=0;i<=samples;i++){
      var x=this.xMin+spanX*i/samples;
      var y=fn(x);
      if(!isFinite(y)){started=false;prevY=null;continue;}
      var px=this.mapX(x)*oz+ox,py=this.mapY(y)*oz+oy;
      if(prevY!==null&&Math.abs(py-prevY)>this.plotH*1.6){started=false;}
      if(!started){ctx.moveTo(px,py);started=true;}else ctx.lineTo(px,py);
      prevY=py;
    }
    ctx.stroke();
  }

  // 交点
  this._drawIntersections(ctx,ox,oz);
};

FunctionItem.prototype._drawIntersections=function(ctx,ox,oz){
  if(this.expressions.length<2)return;
  var samples=720;var spanX=this.xMax-this.xMin;
  var pts=[];
  for(var i=0;i<this.expressions.length;i++){
    for(var j=i+1;j<this.expressions.length;j++){
      var fn1=this.parseExpr(this.expressions[i].expr,this.expressions[i].a);
      var fn2=this.parseExpr(this.expressions[j].expr,this.expressions[j].a);
      var prevX=null,prevD=null;
      for(var s=0;s<=samples;s++){
        var x=this.xMin+spanX*s/samples;
        var y1=fn1(x),y2=fn2(x);
        if(!isFinite(y1)||!isFinite(y2)){prevX=null;prevD=null;continue;}
        var diff=y1-y2;
        if(prevD!==null&&prevX!==null&&Math.sign(prevD)!==Math.sign(diff)){
          // 二分逼近
          var lo=prevX,hi=x;
          for(var k=0;k<45;k++){var mid=(lo+hi)/2;if(fn1(mid)-fn2(mid)>0)hi=mid;else lo=mid;}
          var rootX=(lo+hi)/2;
          var rootY=fn1(rootX);
          if(isFinite(rootY)){
            pts.push({x:rootX,y:rootY});
          }
        }
        prevX=x;prevD=diff;
      }
    }
  }

  // 去重并绘制
  for(var i=0;i<pts.length;i++){
    var pt=pts[i];var px=this.mapX(pt.x)*oz+ox,py=this.mapY(pt.y)*oz+oy;
    var r=Math.max(3,this.width*1.4*oz);
    var colorStr='#'+this.color.toString(16).slice(2);
    ctx.fillStyle=colorStr;ctx.beginPath();ctx.arc(px,py,r,0,2*Math.PI);ctx.fill();
    ctx.strokeStyle=colorStr+'59';ctx.lineWidth=1.2*oz;ctx.beginPath();ctx.arc(px,py,r+1.8*oz,0,2*Math.PI);ctx.stroke();

    var label='('+pt.x.toFixed(3)+', '+pt.y.toFixed(3)+')';
    ctx.fillStyle=colorStr;ctx.font=(this.width*3.8*oz)+'px sans-serif';
    var lx=Math.min(px+r+4,this.left*oz+ox+this.plotW*oz-ctx.measureText(label).width-6);
    ctx.fillText(label,lx,py-r-2);
  }
};

FunctionItem.prototype.hitTest=function(x,y,tol){
  var px=x/oz-ox,py=y/oz-oy;
  return px>=this.left-tol&&px<=this.left+this.plotW+tol&&py>=this.top-tol&&py<=this.top+this.plotH+tol;
};
FunctionItem.prototype.translate=function(dx,dy){this.left+=dx;this.top+=dy;}

// ============ ImageItem ============
var ImageItem=function(img,x,y,w,h){
  this.img=img;this.x=x;this.y=y;this.width=w;this.height=h;
};
ImageItem.prototype.getBounds=function(){return{x:this.x,y:this.y,x2:this.x+this.width,y2:this.y+this.height};};
ImageItem.prototype.draw=function(ctx,ox,oz){
  if(!this.img)return;
  ctx.drawImage(this.img,this.x*oz+ox,this.y*oz+oy,this.width*oz,this.height*oz);
};
ImageItem.prototype.hitTest=function(x,y,tol){
  var px=x/oz-ox,py=y/oz-oy;
  return px>=this.x-tol&&px<=this.x+this.width+tol&&py>=this.y-tol&&py<=this.y+this.height+tol;
};
ImageItem.prototype.translate=function(dx,dy){this.x+=dx;this.y+=dy;}

// ============ 辅助函数 ============
function distToSeg(px,py,ax,ay,bx,by){
  var dx=bx-ax,dy=by-ay,len2=dx*dx+dy*dy;
  if(len2<0.000001)return Math.sqrt((px-ax)**2+(py-ay)**2);
  var t=Math.max(0,Math.min(1,((px-ax)*dx+(py-ay)*dy)/len2));
  return Math.sqrt((px-(ax+t*dx))**2+(py-(ay+t*dy))**2);
}

// ============ Canvas 画布 ============
var canvas=document.getElementById('canvas');
var ctx=canvas.getContext('2d');
var W,H;

function resize(){
  W=window.innerWidth;H=window.innerHeight;
  canvas.width=W;canvas.height=H;
  render();
}
window.addEventListener('resize',resize);

// ============ 状态 ============
var zoom=1,offsetX=0,offsetY=0;
var tool='pen'; // pen, highlighter, eraser, select, pan
var colorStr='#FFFFFF'; // CSS hex for display
var inkColor=0xFFFFFFFF;
var inkWidth=4;
var showGrid=true;
var currentShape='line';
var currentSolid='cube';
var insertMode=null; // shape, solid

// 当前绘制状态
var isDrawing=false,isDragging=false,isPanning=false,isErasing=false;
var startX,startY,lastX,lastY;
var panLastX,panLastY; // 屏幕坐标用于平移
var eraseWX,eraseWY; // 世界坐标用于橡皮擦
var previewItem=null;
var selectedItems=[];
var marqueeStart=null,marqueeCurrent=null;

// ============ 渲染 ============
function render(){
  ctx.clearRect(0,0,W,H);
  // 背景
  ctx.fillStyle='#FFFFFF';ctx.fillRect(0,0,W,H);

  ctx.save();
  ctx.translate(offsetX,offsetY);
  ctx.scale(zoom,zoom);

  // 点阵背景
  if(showGrid){
    var spacing=doc.gridSize*zoom;
    while(spacing<16)spacing*=2;
    if(spacing>0){
      var startX=-offsetX/zoom%spacing;if(startX>0)startX-=spacing;
      var startY=-offsetY/zoom%spacing;if(startY>0)startY-=spacing;
      ctx.fillStyle='rgba(214,218,224,.6)';
      for(var x=startX;x<W/zoom;x+=spacing){
        for(var y=startY;y<H/zoom;y+=spacing){
          ctx.beginPath();ctx.arc(x*zoom,y*zoom,1.15,0,2*Math.PI);ctx.fill();
        }
      }
    }
  }

  // 绘制所有页面中的所有对象
  for(var pi=0;pi<doc.pages.length;pi++){
    var pg=doc.pages[pi];
    if(pg.items){
      for(var i=0;i<pg.items.length;i++){
        var item=pg.items[i];
        if(item.draw)item.draw(ctx,offsetX,offsetY);
      }
    }
  }

  // 绘制当前笔迹
  if(currentStroke&&currentStroke.points.length>0){
    currentStroke.draw(ctx,offsetX,offsetY);
  }

  // 预览形状
  if(previewItem&&previewItem.draw)previewItem.draw(ctx,offsetX,offsetY);

  ctx.restore();

  // 选择框
  drawSelection();

  // 橡皮指示器
  if(tool==='eraser')drawEraserIndicator();

  updatePageText();
}

function drawSelection(){
  if(selectedItems.length===0)return;
  var color='#7EC4E8';
  for(var si=0;si<selectedItems.length;si++){
    var item=selectedItems[si];
    var b=item.getBounds();
    var sx1=b.x*zoom+offsetX,sy1=b.y*zoom+offsetY;
    var sx2=b.x2*zoom+offsetX,sy2=b.y2*zoom+offsetY;
    ctx.strokeStyle=color+'E6';ctx.lineWidth=1.5/zoom;
    ctx.setLineDash([4/zoom,3/zoom]);
    ctx.strokeRect(sx1-4,sy1-4,sx2-sx1+8,sy2-sy1+8);
    ctx.setLineDash([]);

    // 缩放手柄
    if(selectedItems.length===1&&(item instanceof ShapeItem||item instanceof ImageItem||item instanceof SolidItem)){
      ctx.fillStyle=color;
      ctx.fillRect(sx2-8,sy2-8,16,16);
      ctx.strokeStyle='#FFF';ctx.lineWidth=1.5/zoom;ctx.strokeRect(sx2-8,sy2-8,16,16);
    }
  }
}

function drawEraserIndicator(){
  var r=14;
  var ex=(eraseWX!==undefined?eraseWX:0)*zoom+offsetX;
  var ey=(eraseWY!==undefined?eraseWY:0)*zoom+offsetY;
  ctx.fillStyle='rgba(0,0,0,.1)';
  ctx.strokeStyle='#CCC';ctx.lineWidth=1.2/zoom;
  ctx.beginPath();ctx.arc(ex,ey,r*zoom,r*2*Math.PI);ctx.fill();ctx.stroke();
}

// ============ 坐标转换 ============
function screenToWorld(sx,sy){return{x:(sx-offsetX)/zoom,y:(sy-offsetY)/zoom};}
function worldToScreen(wx,wy){return{x:wx*zoom+offsetX,y:wy*zoom+offsetY};}

// ============ 拾取 ============
function pickItem(wx,wy,tol){
  for(var i=doc.pages[doc.currentPageIndex].items.length-1;i>=0;i--){
    var item=doc.pages[doc.currentPageIndex].items[i];
    if(item.hitTest&&item.hitTest(wx,wy,tol))return item;
  }
  return null;
}

// ============ 输入处理 ============
var currentStroke=null;

canvas.addEventListener('pointerdown',function(e){
  var wx=(e.clientX-offsetX)/zoom,wy=(e.clientY-offsetY)/zoom;

  if(tool==='pan'||tool==='select'){
    var picked=pickItem(wx,wy,8/zoom);
    if(picked&&tool==='select'){
      // 检查是否点中缩放手柄
      var b=picked.getBounds();
      var hx=b.x2*zoom+offsetX,hy=b.y2*zoom+offsetY;
      if(Math.abs(e.clientX-hx)<12&&Math.abs(e.clientY-hy)<12){
        startResize={x:e.clientX,y:e.clientY,item:picked};return;
      }
      if(!selectedItems.includes(picked)){selectedItems=[picked];}
      isDragging=true;startX=wx;startY=wy;
    }else{selectedItems=[];}
    isPanning=true;panLastX=e.clientX;panLastY=e.clientY;
  }else if(tool==='pen'||tool==='highlighter'){
    currentStroke=new InkStroke(inkColor,inkWidth,tool==='highlighter');
    currentStroke.addPoint(wx,wy,e.pressure||0.5,1);
    isDrawing=true;
  }else if(tool==='eraser'){
    isErasing=true;eraseWX=wx;eraseWY=wy;
  }else if(insertMode==='shape'){
    startX=wx;startY=wy;isDrawing=true;
  }else if(insertMode==='solid'){
    var solid=new SolidItem(currentSolid,0xFFFFFFFF,160,160);
    solid.cx=wx;solid.cy=wy;
    getCurrentPage().items.push(solid);selectedItems=[solid];render();insertMode=null;
  }
  render();
});

var startResize=null;
canvas.addEventListener('pointermove',function(e){
  var wx=(e.clientX-offsetX)/zoom,wy=(e.clientY-offsetY)/zoom;

  if(isDrawing&&tool==='pen'){
    currentStroke.addPoint(wx,wy,e.pressure||0.5,1);render();
  }else if(isDrawing&&tool==='highlighter'){
    if(!currentStroke){currentStroke=new InkStroke(inkColor,inkWidth,true);}
    currentStroke.addPoint(wx,wy,e.pressure||0.5,1);render();
  }else if(isErasing){
    // 擦除逻辑
    eraseWX=wx;eraseWY=wy;
    var pg=getCurrentPage();
    for(var i=pg.items.length-1;i>=0;i--){
      var item=pg.items[i];
      if(item instanceof InkStroke){
        var remains=item.eraseAt(wx,wy,14/zoom);
        if(remains.length>0){
          pg.items.splice(i,1);
          for(var r=0;r<remains.length;r++)pg.items.push(remains[r]);
        }else if(item.points.length>0&&item.hitTest(wx,wy,0)){
          pg.items.splice(i,1);
        }
      }
    }
    render();
  }else if(isPanning){
    offsetX+=e.clientX-panLastX;offsetY+=e.clientY-panLastY;
    panLastX=e.clientX;panLastY=e.clientY;render();
  }else if(isDragging&&tool==='select'){
    var dx=wx-startX,dy=wy-startY;
    for(var i=0;i<selectedItems.length;i++){
      selectedItems[i].translate(dx,dy);
    }
    startX=wx;startY=wy;render();
  }else if(isDrawing&&insertMode==='shape'){
    // 预览形状
    previewItem=new ShapeItem(currentShape,inkColor,inkWidth);
    previewItem.x1=startX;previewItem.y1=startY;previewItem.x2=wx;previewItem.y2=wy;
    render();
  }

  lastX=wx;lastY=wy;
});

canvas.addEventListener('pointerup',function(e){
  var wx=(e.clientX-offsetX)/zoom,wy=(e.clientY-offsetY)/zoom;

  if(isDrawing&&tool==='pen'&&currentStroke){
    getCurrentPage().items.push(currentStroke);currentStroke=null;isDrawing=false;
  }else if(isDrawing&&tool==='highlighter'&&currentStroke){
    getCurrentPage().items.push(currentStroke);currentStroke=null;isDrawing=false;
  }else if(isDrawing&&insertMode==='shape'&&previewItem){
    previewItem.x2=wx;previewItem.y2=wy;
    getCurrentPage().items.push(previewItem);previewItem=null;isDrawing=false;
  }

  isDrawing=false;isPanning=false;isDragging=false;isErasing=false;
  render();
});

// 滚轮缩放
canvas.addEventListener('wheel',function(e){
  e.preventDefault();
  var factor=e.deltaY>0?0.9:1.1;
  var wx=(e.clientX-offsetX)/zoom,wy=(e.clientY-offsetY)/zoom;
  zoom=Math.min(6,Math.max(0.15,zoom*factor));
  offsetX=e.clientX-wx*zoom;offsetY=e.clientY-wy*zoom;
  render();updateZoomText();
});

// ============ 工具函数 ============
window.setTool=function(t){
  tool=t;insertMode=null;
  document.querySelectorAll('.tool-btn').forEach(function(b){b.classList.toggle('active',b.dataset.tool===t);});
  document.getElementById('inkOptions').classList.toggle('show',t==='pen'||t==='highlighter');
  document.getElementById('eraserOptions').classList.toggle('show',t==='eraser');
  canvas.style.cursor=t==='pan'?'grab':t==='select'?'default':'crosshair';
};


window.setColor=function(el){
  var hex=el.dataset.color;
  inkColor=parseInt(hex,16);
  document.querySelectorAll('.swatch').forEach(function(s){s.classList.remove('active');});
  el.classList.add('active');
  updateInkPreview();
};

window.setCustomColor=function(hex){
  var c=hexToRGBA(hex);
  inkColor=0xFF<<24|c.r<<16|c.g<<8|c.b;
  document.querySelectorAll('.swatch').forEach(function(s){s.classList.remove('active');});
  document.getElementById('customColorPicker').style.background=hex;
  updateInkPreview();
};

window.setWidth=function(v){
  inkWidth=Math.min(40,Math.max(1,parseInt(v)));
  updateInkPreview();render();
};

function updateInkPreview(){
  var preview=document.getElementById('inkOptions');
  // 在 UI 上更新预览
}

window.setShape=function(s){
  currentShape=s;
  document.querySelectorAll('.shape-btn').forEach(function(b){b.classList.toggle('active',b.dataset.shape===s);});
};

window.setSolid=function(s){
  currentSolid=s;
  document.querySelectorAll('.solid-btn').forEach(function(b){b.classList.toggle('active',b.dataset.solid===s);});
};

window.showShapePicker=function(){
  document.getElementById('shapePicker').style.display='flex';
  document.getElementById('solidPicker').style.display='none';
  insertMode='shape';
  setTool(null); // 不选中任何工具按钮
};

window.showSolidPicker=function(){
  document.getElementById('solidPicker').style.display='flex';
  document.getElementById('shapePicker').style.display='none';
  insertMode='solid';
  setTool(null);
};

window.toggleInsert=function(){
  var el=document.getElementById('insertFlyout');
  el.classList.toggle('show',el.classList.contains('show')===false);
};

window.toggleMenu=function(){
  document.getElementById('menuFlyout').classList.toggle('show');
};

// ============ 撤销/恢复 ============
var undoStack=[],redoStack=[];
window.undo=function(){
  if(!undoStack.length)return;
  var state=undoStack.pop();redoStack.push(saveState());
  var pg=getCurrentPage();pg.items=state.items||[];selectedItems=[];render();
};
window.redo=function(){
  if(!redoStack.length)return;
  var state=redoStack.pop();undoStack.push(saveState());
  var pg=getCurrentPage();pg.items=state.items||[];selectedItems=[];render();
};

// ============ 页面管理 ============
function updatePageText(){
  document.getElementById('pageText').textContent=(doc.currentPageIndex+1)+'/'+doc.pages.length;
  document.getElementById('prevPageBtn').disabled=doc.currentPageIndex===0;
  document.getElementById('nextPageBtn').disabled=doc.currentPageIndex>=doc.pages.length-1;
}

window.prevPage=function(){if(doc.currentPageIndex>0){doc.currentPageIndex--;selectedItems=[];render();}};
window.nextPage=function(){if(doc.currentPageIndex<doc.pages.length-1){doc.currentPageIndex++;selectedItems=[];render();}};
window.addPage=function(){
  doc.pages.splice(doc.currentPageIndex+1,0,{items:[]});
  doc.currentPageIndex=doc.currentPageIndex+1;selectedItems=[];undoStack=[];redoStack=[];render();
};
window.deletePage=function(){
  if(doc.pages.length<=1)return;if(confirm('确定删除本页？')){
    doc.pages.splice(doc.currentPageIndex,1);if(doc.currentPageIndex>=doc.pages.length)doc.currentPageIndex=doc.pages.length-1;
    selectedItems=[];undoStack=[];redoStack=[];render();
  }
};

// ============ 视图操作 ============
window.resetView=function(){zoom=1;offsetX=W/2;offsetY=H/2;render();updateZoomText();};
function updateZoomText(){document.getElementById('zoomReset').textContent=Math.round(zoom*100)+'%';}

window.fitToContent=function(){
  var pg=getCurrentPage();if(!pg.items.length){resetView();return;}
  var minX=1e9,minY=1e9,maxX=-1e9,maxY=-1e9;
  for(var i=0;i<pg.items.length;i++){
    var b=pg.items[i].getBounds();
    if(b.x<minX)minX=b.x;if(b.y<minY)minY=b.y;if(b.x2>maxX)maxX=b.x2;if(b.y2>maxY)maxY=b.y2;
  }
  var cw=maxX-minX,ch=maxY-minY;
  zoom=Math.min(W/cw,H/ch)*0.9;zoom=Math.max(0.15,Math.min(6,zoom));
  offsetX=W/2-(minX+cw/2)*zoom;offsetY=H/2-(minY+ch/2)*zoom;render();updateZoomText();
};

window.toggleGrid=function(){showGrid=!showGrid;render();};
window.clearBoard=function(){getCurrentPage().items=[];selectedItems=[];undoStack=[];redoStack=[];render();};

// ============ 文件操作 ============
window.openFile=function(){document.getElementById('fileInput').click();};
function handleFileOpen(e){
  var file=e.target.files[0];if(!file)return;
  var reader=new FileReader();
  reader.onload=function(ev){
    try{var data=JSON.parse(ev.target.result);doc.pages=data.pages||[{items:[]}];doc.currentPageIndex=0;selectedItems=[];undoStack=[];redoStack=[];render();}
    catch(err){showToast('文件解析失败');}
  };reader.readAsText(file);e.target.value='';
};

window.saveFile=function(){
  var data={pages:doc.pages,version:1};
  var blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
  var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='whiteboard.setb';a.click();
};

window.exportPng=function(){
  // 创建离屏 canvas 导出
  var pg=getCurrentPage();if(!pg.items.length){showToast('画板为空');return;}
  var minX=1e9,minY=1e9,maxX=-1e9,maxY=-1e9;
  for(var i=0;i<pg.items.length;i++){var b=pg.items[i].getBounds();if(b.x<minX)minX=b.x;if(b.y<minY)minY=b.y;if(b.x2>maxX)maxX=b.x2;if(b.y2>maxY)maxY=b.y2;}
  var cw=maxX-minX+48,ch=maxY-minY+48;
  var offCanvas=document.createElement('canvas');offCanvas.width=cw*2;offCanvas.height=ch*2;
  var offCtx=offCanvas.getContext('2d');
  offCtx.fillStyle='#FFF';offCtx.fillRect(0,0,offCanvas.width,offCanvas.height);
  offCtx.scale(2,2);offCtx.translate(-minX+24,-minY+24);

  for(var i=0;i<pg.items.length;i++){if(pg.items[i].draw)pg.items[i].draw(offCtx,0,1);}

  offCanvas.toBlob(function(blob){
    var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='page.png';a.click();
  });
};

// ============ 函数图像 ============
window.showFuncDialog=function(){document.getElementById('funcDialog').classList.add('show');document.getElementById('funcInput').focus();};
window.closeFuncDialog=function(){document.getElementById('funcDialog').classList.remove('show');};

window.insertFunction=function(){
  var expr=document.getElementById('funcInput').value.trim();
  if(!expr)return;
  var range=document.getElementById('funcRange').value.split(',');
  closeFuncDialog();
  var fi=new FunctionItem();
  fi.xMin=parseFloat(range[0])||-10;fi.xMax=parseFloat(range[1])||10;
  // 自动 Y 范围
  var fn=fi.parseExpr(expr,1);var vals=[];
  for(var i=0;i<=256;i++){var x=fi.xMin+(fi.xMax-fi.xMin)*i/256;var y=fn(x);if(isFinite(y)&&Math.abs(y)<1e6)vals.push(y);}
  if(vals.length>8){vals.sort(function(a,b){return a-b;});var lo=vals[Math.floor(vals.length*0.05)],hi=vals[Math.floor(vals.length*0.95)];fi.yMin=lo-(hi-lo)*0.12;fi.yMax=hi+(hi-lo)*0.12;}
  else{fi.yMin=-4;fi.yMax=4;}
  // 放到视野中央
  var center=screenToWorld(W/2,H/2);
  fi.left=center.x-fi.plotW/2;fi.top=center.y-fi.plotH/2;
  fi.addCurve(expr,inkColor,1);
  getCurrentPage().items.push(fi);selectedItems=[fi];render();
};

// ============ 图片插入 ============
window.insertImage=function(){document.getElementById('imageInput').click();};
function handleImageInsert(e){
  var file=e.target.files[0];if(!file)return;
  var reader=new FileReader();
  reader.onload=function(ev){
    var img=new Image();img.onload=function(){
      var center=screenToWorld(W/2,H/2);
      var iw=Math.min(img.width*0.5,400),ih=iw/img.width*img.height;
      var ii=new ImageItem(img,center.x-iw/2,center.y-ih/2,iw,ih);
      getCurrentPage().items.push(ii);selectedItems=[ii];render();
    };img.src=ev.target.result;
  };reader.readAsDataURL(file);e.target.value='';
}

// ============ Toast ============
function showToast(msg){var t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(function(){t.classList.remove('show');},2000);}

// ============ 关于 ============
window.showAbout=function(){document.getElementById('aboutDialog').classList.add('show');};
window.closeAbout=function(){document.getElementById('aboutDialog').classList.remove('show');};

// ============ 键盘快捷键 ============
document.addEventListener('keydown',function(e){
  if(e.ctrlKey&&e.key==='z'){e.preventDefault();undo();}
  else if(e.ctrlKey&&e.key==='y'){e.preventDefault();redo();}
  else if(e.ctrlKey&&e.key==='s'){e.preventDefault();saveFile();}
  else if(e.ctrlKey&&e.key==='o'){e.preventDefault();openFile();}
  else if(e.key==='Delete'&&selectedItems.length){
    for(var i=0;i<selectedItems.length;i++)getCurrentPage().items.splice(getCurrentPage().items.indexOf(selectedItems[i]),1);
    selectedItems=[];render();
  }
});

// ============ 初始化 ============
resize();
doc.pages.push({items:[]});
offsetX=W/2;offsetY=H/2;
render();

})();
